<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Observatoire de la couverture de réseau mobile de la Côte d'Ivoire</title>
</head>
<body style="background: #e5e5e5; padding: 30px;" >
	<h1></h1>

<div style="max-width: 320px; margin: 0 auto; padding: 20px; background: #fff;">
	<h3 style="text-align: center">Nouveau Commentaire</h3>
		
		<div class="row">
			<div class="col-md-3">
				Contenu:
			</div>
			<div style="padding:5px; background:rgb(194, 253, 253)">
				<div class="bg-light">
					Vous avez reçu un nouveau commentaire.
				</div>
			</div>
		</div>
</div>

</body>
</html>