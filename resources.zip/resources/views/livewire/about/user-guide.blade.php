<div>
    <div class="d-flex justify-center pt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="text-center">
                    <h2>Ouuups ! </h2>
                    <h2 style="font-size: 50px;" class="text-center">Page en développement</h2>
                    
                </div>
            </div>
            <div class="col-md-12 d-flex justify-center">
                
                    <img src="images/danger.jpg" alt="">
            </div>
        </div>
    </div>
</div>
